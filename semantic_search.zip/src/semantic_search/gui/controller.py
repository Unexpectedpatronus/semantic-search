"""Контроллер для связи GUI и логики обработки/поиска документов"""

from pathlib import Path
from typing import Dict, List

from semantic_search.core.document_processor import DocumentProcessor, ProcessedDocument
from semantic_search.core.search_engine import SemanticSearchEngine
from semantic_search.utils.notification_system import NotificationManager
from semantic_search.utils.statistics import calculate_statistics_from_processed_docs


class AppController:
    def __init__(self):
        self.processor = DocumentProcessor()
        self.documents: List[ProcessedDocument] = []
        self.engine: SemanticSearchEngine | None = None
        self.notifier = NotificationManager()

    def load_documents(self, folder: Path) -> Dict[str, str]:
        self.documents.clear()
        self.documents.extend(self.processor.process_documents(folder))

        self.engine = SemanticSearchEngine([doc.tokens for doc in self.documents])
        stats = calculate_statistics_from_processed_docs(self.documents)
        return {
            "status": f"Загружено документов: {stats['processed_files']}",
            "details": str(stats),
        }

    def search(self, query: str) -> List[Dict[str, str]]:
        if not self.engine:
            return []

        results = self.engine.search(query)

        return [
            {
                "title": doc.relative_path,
                "path": str(doc.file_path),
                "score": round(score, 4),
            }
            for (doc, score) in results
        ]
